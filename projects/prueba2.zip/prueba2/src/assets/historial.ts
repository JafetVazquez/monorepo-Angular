export class Historial{
    constructor(
       public id: string,
       public id_ticket: string,
       public id_usuario: string,
       public fc_modificacion: Date,
       public id_estatus: string,
       public id_especialista: string

    ){}
    
}