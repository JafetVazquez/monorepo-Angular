export const environment = {
  production: true,
  //apiUrl: 'http://10.100.128.29:8000'
  apiUrl: 'http://localhost:3000'
  // apiUrl: 'http://192.168.1.128:8000'
};
